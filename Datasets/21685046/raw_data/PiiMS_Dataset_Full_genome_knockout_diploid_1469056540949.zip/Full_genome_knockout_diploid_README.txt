Dataset_390_Detail_1299877528453.csv
The raw optical density adjusted ICP-MS data in this knockout dataset of 1,127 essential genes (tested as heterozygous diploid yeast strains) was normalized across the complete population using the common line BY4741 to remove batch and plate effects.

Dataset_390_Aggregate_1299877732527.csv
Percentage change of normalized values compared to population mean. The normalized values are adjusted to avoid the negative values. Note: The ratios are not multiplied by 100%.

Dataset_390_Aggregate_1299877794236.csv
Moderated Z statistic for a mutant line is the change in abundance from the population mean divided by the deviation. The deviation is equal to the square root of the summation of the sample variance in the mutant and the between-plate variance from a common line YDL227C.


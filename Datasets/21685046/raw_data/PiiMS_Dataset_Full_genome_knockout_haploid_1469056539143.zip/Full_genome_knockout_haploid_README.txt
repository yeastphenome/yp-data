Dataset_387_Detail_1299870024307.csv
The raw optical density adjusted ICP-MS data in this full genome knockout dataset of 4,940 unique haploid yeast strains was normalized across the complete population using the common line BY4741 to remove batch and plate effects.

Dataset_387_Aggregate_1299870873410.csv
Aggregate Information Percentage change of normalized values compared to population mean. The normalized values are adjusted to avoid the negative values. Note: The ratios are not multiplied by 100%.

Dataset_387_Aggregate_1299871000141.csv
Aggregate Information Moderated Z statistic for a mutant line is the change in abundance from the population mean divided by the deviation. The deviation is equal to the square root of the summation of the sample variance in the mutant and the between-plate variance from a common line YDL227C.


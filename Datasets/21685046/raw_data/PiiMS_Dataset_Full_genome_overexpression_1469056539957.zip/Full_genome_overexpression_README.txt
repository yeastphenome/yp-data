Dataset_389_Detail_1299875757665.csv
The raw optical density normalized ICP-MS data in this full genome open reading frame (ORF) overexpression dataset of 5,798 unique yeast strains was normalized across the complete population using the common line YMR243C to remove batch and plate effects.

Dataset_389_Aggregate_1299877271331.csv
Information Percentage change of normalized values compared to population mean. The normalized values are adjusted to avoid the negative values. Note: The ratios are not multiplied by 100%.

Dataset_389_Aggregate_1299877861025.csv
Moderated Z statistic for a mutant line is the change in abundance from the population mean divided by the deviation. The deviation is equal to the square root of the summation of the sample variance in the mutant and the between-plate variance from a common line YDL227C.

